// 写一个数组的处理函数，mofidyArray 
// input: [0,1,2,3,4,5,6]  ->  [2,4,6,8,10,12];

const modifyArrCmd2 = (arr) => {
    const result = [];
    for(let i = 0; i < arr.length; i++) {
        if(arr[i] !== 0) {
            result.push(arr[i] * 2)
        }
    }
    return result;
}


const modifyArrCmd3 = (arr) => {
    const result = [];
    for(let i = 0; i < arr.length; i++) {
        if(arr[i] !== 0) {
            result.push(arr[i] * 3)
        }
    }
    return result;
}

let arr = [0,1,2,3,4,5,6];
console.log(modifyArrCmd(arr));

// 思路：
// 第一步：数组要经历一个筛选函数，把 0 筛除掉；
// 第二步：数组要经历一个乘法函数，每一个数据，*2；

const modifyArrFP = (arr) => arr
    .filter(Boolean)
    .map(item => item*2);

console.log(modifyArrFP(arr));

// 更想说的一点是： map/filter/reduce 其实比 forEach 更加 FPify
// React 比 Vue 更加 FPify