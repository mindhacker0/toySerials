/**
 * const modifyArrFP = (arr) => arr
    .filter(Boolean)
    .map(item => item*2);
 */

const filterBoolean = arr => arr.filter(Boolean);
const filterBigger = numm => arr => arr.filter(item => item <= num);
const filterBigger10 = filterBigger(10);
// 科里化。我用科里化，把一个乘法器，拆解了。
const multiply = num => arr => arr.map(item => item * num);

// const _multiply = function(num) {
//     return function(arr) {
//         return arr.map(item => item * num)
//     }
// }

// 我们通过使用科里化的方式，很容易地，生成了两个新的函数
const multiplyTwo = multiply(2);
const multiplyThree = multiply(3);
                //                         [fn1, fn2, fn3]
                //                                                     fn1(startNum)  -- >
                //                                                     fn2(fn1(startNum)) -->
                //                                                     fn3(fn2(fn1(startNum)))
const compose = (...rest) => stratNum => rest.reduce((total, item) => item(total), stratNum);
// fn1, fn2, fn3  -> fn3(fn2(fn1(startNum)))

const modifyArr2 = compose(filterBoolean, multiplyThree, filterBigger10);
// 流水线。
// 拦截器。

const arr = [0,1,2,3,4,5,6];
console.log(modifyArr2(arr));

// 对修改封闭，对扩展开放。

