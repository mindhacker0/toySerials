// 假如，我有一个计算密集型的函数
// 我希望对这个函数进行包装，如何让这个函数如果之前计算过了
// 我就不再计算了，直接返回值。

const memorize = fn => {
    let cacheMap = {};
    return function(...args) {
        const cacheKey = args.join('_');
        if(cacheKey in cacheMap) {
            return cacheMap[cacheKey];
        } else {
            return cacheMap[cacheKey] = fn.apply(this || {}, args);
        }
    }
}

function add(a, b) {
    console.log(a, b);
    return a+b;
}

const madd = memorize(add);
madd(1,2);
madd(1,2);
madd(1,2);
