// 计算一个折扣
var strategies = {
    "S": salary => salary * 4,
    "A": salary => salary * 3,
    "B": salary => salary * 2
}

var calculateBonus = function(level, salary) {
    return strategies[level](salary);
}