/**
 * add(1)(2) == 3;
 * add(1)(2)(3) == 6;
 * 
 * 1. 函数的科里化。
 * 2. 当我去使用这个函数的时候，我能够转成 value.
 */

const add = (arg1) => {
    let args = [arg1];
    const fn = arg2 => {
        args.push(arg2);
        return fn;
    }
    // 当我进行判断的时候，我再调用这个方法
    fn.toString = function() {
        return args.reduce((prev, item) => prev + item, 0)
    }
    return fn;
}

console.log(add(1)(2) == 3, add(1)(2)(3)(4) == 10);


const add2 = (...arg1) => {
    let args = [...arg1];
    const fn = (...arg2) => {
        args = [...args, ...arg2];
        if(args.length === 5) {
            return args.reduce((prev, item) => prev + item, 0)
        } else {
            return fn;
        }
        
    }
   
    return fn;
}

// 如果直接输出6
// add(1)(2)(3)(4)
// new Promise()
// lazyMan
