// 
const fn = () => {
    console.log('this is an API request...');
}

const bf1 = () => {
    console.log('this is the befored1 function running');
}
const bf2 = () => {
    console.log('this is the befored2 function running');
}
const bf3 = () => {
    console.log('this is the befored3 function running');
}

// 请实现一个 warppedFn 包装我的fn，让bf1 先执行

const warppedBefore = function(fn, before) {
    return function(...args){
        before();
        return fn.apply(this, args);
    }
}

// const warppedFn = warppedBefore(fn, bf1);
// warppedFn();

// 1. before 能不能是一个数组。
// 2. 怎么样执行
// 3. 字符串的校验。
const compose = (...rest) => stratNum => rest.reduce((total, item) => item(total), stratNum);

const warppedBeforeList = function(fn, ...bf) {
    return function(args){
        const c = compose(...bf)(args);
        return fn.apply(this, c);
    }
}

const warppedFn = warppedBeforeList(fn, bf1, bf2, bf3);
warppedFn([0,1,2,3,4,5]);