console.log('welcome');
console.log(performance.timing);

// 在浏览器端，使用 performance ，除了 直接用 performance.timing , 还有一种用法
// 主要是使用 PerformanceObserver 

var observer = new PerformanceObserver(function(list) {
    var preEntires = list.getEntries();
    for(var i = 0; i < preEntires.length; i++) {
        console.log(preEntires[i]);
    }
});

observer.observe({
    entryTypes:[ "element", 
        "event", 
        "first-input", 
        "largest-contentful-paint", 
        "layout-shift",
        "longtask",
        "mark",
        "measure",
        "navigation", "paint", "resource" ]
});

for(let i = 0; i < 10000000; i++) {
    new Array(100);
}
