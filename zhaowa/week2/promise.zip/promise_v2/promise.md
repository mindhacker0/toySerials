## promise 解析
* 啥是异步
```js   
    // 异步执行
    let count = 1;
    let timer = setTimeout(function() {
        count++;
        console.log('in', count);
    }, 1000);

    console.log('out', count);

    // 循环执行 + 终止
    let count = 1;
    let timer = setInterval(function() {
        count++;
        console.log('in', count);
    }, 1000);

    console.log('out', count);
    setTimeout(function() {
        clearInterval(timer);
        console.log('clear');
    }, 5000);

    // 看不见的队列，存放着他需要摸摸执行的命令
```

### 1. 进程 & 线程
#### a.概念与区别 - 见图

#### b.面试题：
* 映射到前端 - 浏览器。 chrome新开一个窗口，是进程还是线程？- 进程，从区别概念回答
* 发散：
方向一：窗口（进程间）通信？- storage、cookie => 多种存储区别 => 应用场景
方向二：浏览器原理（中高级岗位面试居多）

### 2. EVENT-LOOP
#### a. 执行栈
* JS单线程语言，单步执行
```js
function func2() {
    throw new Error('plz check your call stack');
}

function func1() {
    func2();
}

function run() {
    func1();
}

run();
```

#### b. 面试题
* JS堆栈执行顺序与堆栈溢出 / 爆栈 / 性能卡顿 / 死循环 => JS性能优化
```js
    function func() {
        func();
    }
    func();
    // vue - computed 对某个ob变量做了赋值 => 禁止
```
* 执行顺序题
解题思路 - 任务纬度
```js
    setTimeout(() => {
        console.log('Timeout'); // 5. 宏任务2
    }, 0);

    new Promise(resolve => {
        console.log('new Promise'); // 1. 属于同步进入主线程 宏任务1
        resolve();
    }).then(() => {
        console.log('Promise then'); // 3. 微任务 1
    }).then(() => {
        console.log('Promise then then'); // 4. 微任务 2
    })

    console.log('hi'); // 2. 同步 + 宏任务1
```

### promise
#### a. 理论
```js
    // 1. 写一个异步定时
    setTimeout(() => {
        console.log('time out');
    }, 2000);

    // 2. 异步请求
    request.onreadystatechange = () => {
        if(request.readyState === 4) {
            const _status = request.status;
            if (_status === 200) {
                const _res = request.responseText;
                return successs(_res);
            } else {
                return fail(_status);
            }
        }
    }

    // 3. 延时后再请求
    setTimeout(() => {
        console.log('time out');
        request.onreadystatechange = () => {
            if(request.readyState === 4) {
                const _status = request.status;
                if (_status === 200) {
                    const _res = request.responseText;
                    return successs(_res);
                } else {
                    return fail(_status);
                }
            }
        }
    }, 2000);

    // 4. 请求完成后，再等2s，再下一个请求
    setTimeout(() => {
        console.log('time out');
        request.onreadystatechange = () => {
            if(request.readyState === 4) {
                const _status = request.status;
                if (_status === 200) {
                    const _res = request.responseText;
                    setTimeout(() => {
                        console.log('time out');
                        request.onreadystatechange = () => {
                            if(request.readyState === 4) {
                                const _status = request.status;
                                if (_status === 200) {
                                    const _res = request.responseText;
                                    return successs(_res);
                                } else {
                                    return fail(_status);
                                }
                            }
                        }
                    }, 2000);
                    return successs(_res);
                } else {
                    return fail(_status);
                }
            }
        }
    }, 2000);

    // 4.5 再再……
    // 回调地狱

    // 5. promise的出现拯救了回调导致的无穷嵌套
    new Promise((resolve, reject) => {
        setTimout(() => {
            resolve('OK');
        })
    }).then(res => {
        // io请求
        console.log('then' + res);
    }).catch(err => {
        console.log('catch' + err);
    })

    // 6. 多个异步顺序执行 => 复合链式调用
    function wait500(input) {
        return new Promise((resolve, reject) => {
            console.log('500', input);
            setTimeout(() => {
                resolve(input + 500);
            }, 500);
        })
    }

    function wait1000(input) {
        return new Promise((resolve, reject) => {
            console.log('1000', input);
            setTimeout(() => {
                resolve(input + 1000);
            }, 1000);
        })
    }

    const p = new Promise((resolve, reject) => {
        resolve(1);
    });

    p.then(wait500)
     .then(wait1000)
     .then(wait500)
     .then(wait1000)
     .then(result => {
         console.log('end', result);
     })

     // 7. 全部执行，执行完成全部promise后，再回调
     Promise.all([wait500, wait1000]).then(result => {
          console.log('all end', result);
     });

     // 8. 有执行完成的，立刻操作
     Promise.race([wait500, wait1000]).then(result => {
          console.log('all end', result);
     })
```

#### b. 面试 - Promise/A+
* 1. promise有哪些状态？对应值有哪些？
promise：pending、fulfilled、rejected
executor：new Promise的时候立即执行，接收两个参数resolve + reject

* 2. promise的默认状态是？状态如何流转？
默认状态：pending
内部维护成功value：undefined、thenable、promise
内部维护失败变量reason

promise状态流转 pending => rejected 、 pending => fulfilled

* 3. promise的返回值？
then方法：接收onFulfilled和onRejected

如果then时，promise已经成功，执行onFulfilled，参数value

如果then时，promise已经失败，执行onRejected，参数是reason

如果then中有异常传递onRejected

* 4. 手写promise - 基本同步版本
```js
const PENDING = 'PENDING';
const FULFILLED = 'FULFILLED';
const REJECTED = 'REJECTED';

class Promise {
    constructor(executor) {
        // 1. 默认状态 - PENDING
        this.status = PENDING;
        // 2. 维护内部成功失败的值
        this.value = undefined;
        this.reason = undefined;

        // 成功回调
        let resolve = value => {
            // 单向流转
            if(this.status === PENDING) {
                this.status = FULFILLED;
                this.value = value;
            }
        }

        // 失败的回调
        let reject = reason => {
            if(this.status === PENDING) {
                this.status = REJECTED;
                this.reason = reason;
            }
        }

        try {
            executor(resolve, reject);
        } catch(error) {
            reject(error);
        }
    }

    then(onFulfilled, onRejected) {
        if(this.status === FULFILLED) {
            onFulfilled(this.value);
        }

        if(this.status === REJECTED) {
            onRejected(this.reason);
        }
    }
}

// 家庭作业 - 异步方式 => 维护队列
class Promise {
    constructor(executor) {
        // 1. 默认状态 - PENDING
        this.status = PENDING;
        // 2. 维护内部成功失败的值
        this.value = undefined;
        this.reason = undefined;

        // 存放成功的回调
        this.onResolvedCallbacks = [];
        // 存放失败的回调
        this.onRejectedCallbacks = [];

        // 成功回调
        let resolve = value => {
            // 单向流转
            if(this.status === PENDING) {
                this.status = FULFILLED;
                this.value = value;
                this.onResolvedCallbacks.forEach(fn => fn());
            }
        }

        // 失败的回调
        let reject = reason => {
            if(this.status === PENDING) {
                this.status = REJECTED;
                this.reason = reason;
                this.onRejectedCallbacks.forEach(fn => fn());
            }
        }

        try {
            executor(resolve, reject);
        } catch(error) {
            reject(error);
        }
    }

    then(onFulfilled, onRejected) {
        if(this.status === FULFILLED) {
            onFulfilled(this.value);
        }

        if(this.status === REJECTED) {
            onRejected(this.reason);
        }

        if (this.status === PENDING) {
            // 存放执行队列
            this.onResolvedCallbacks.push(() => {
                onFulfilled(this.value);
            })
            this.onRejectedCallbacks.push(() => {
                onRejected(this.reason);
            })
        }
    }
}

```

### async await & generator
```js
    // 1. async await
    function wait500(input) {
        return new Promise((resolve, reject) => {
            console.log('500', input);
            setTimeout(() => {
                resolve(input + 500);
            }, 500);
        })
    }

    async function asyncCall() {
        const result = undefined;
        result = await wait500(0);
        console.log('asyncCall', result);
    }
    asyncCall();

    // 2. 步进 手动代替then
    function* generator() {
        let index = 0;
        while(true) yield index++;
    }

    let gen = generator();

    console.log(gen.next().value); // 0
    console.log(gen.next().value); // 1
    console.log(gen.next().value); // 2

    // 3. 结合流水线自动化
    const GEN_LINE = [1, 2, 3, 4, 5, 6];

    (GEN_LINE || []).forEach(it => {
        console.log(gen.next(it).value);
    })

    // io
```
