const hello = my_require('./module.js');

console.log(`
    hello luyi,
    ${hello()}
`)

