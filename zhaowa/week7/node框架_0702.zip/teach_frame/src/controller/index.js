import Book from './bookController'
import User from './userController'

export default [
    Book, User
]